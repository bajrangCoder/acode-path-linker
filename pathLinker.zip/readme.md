# PathLinker

It helps you to easily navigate to other files that are linked in your currently opened file (same as vscode feature)

## How to use it?
<video controls>
  <source src="" type="video/mp4">
</video>


**Contribution are welcome 🥰!**

**For Features Request or Bug report -> [here](https://github.com/bajrangCoder/acode-path-linker)**

**Thanks for using ❣️❤️, Leave a 🌟 [here](https://github.com/bajrangCoder/acode-path-linker)**